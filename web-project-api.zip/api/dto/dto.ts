export interface DTO {
  createdAt :Date;
  updatedAt :Date;
  deletedAt :Date | null;
}