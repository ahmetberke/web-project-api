import React from 'react'

export const Logo = () => {
  return (
    <div className="h-full flex justify-center items-center">
      <span className="text-teal-400 text-sm font-black">OKUR YAZAR</span>
    </div>
  )
}
